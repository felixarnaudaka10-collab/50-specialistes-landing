# 70 Spécialistes IA pour Claude

**Par Maîtrise IA — Arnaud Aka**
🔗 https://50-specialistes-ia.netlify.app
📸 @arnaud_aka

---

## C'est quoi ?

70 experts autonomes intégrés directement dans Claude. Chacun maîtrise un domaine précis du business en ligne — marketing, vente, contenu, croissance, productivité. Tu n'as pas à tout savoir. Tu as juste à demander au bon spécialiste.

Ce ne sont pas des prompts. Ce sont des systèmes complets qui analysent, créent et livrent — en automatique.

---

## Les 70 Spécialistes

### 🎯 Vente & Offre
| Spécialiste | Expertise |
|------------|-----------|
| **Victor** | Stratégie de vente & closing |
| **Charlotte** | Offres high-ticket & premium |
| **Max** | Création d'offre irrésistible |
| **Lucas** | Stratégie de pricing |
| **Chloe** | Scripts de vente & argumentaires |
| **Sienna** | Tunnel de vente & funnel |
| **Alice** | Funnel marketing complet |

### ✍️ Copywriting & Contenu
| Spécialiste | Expertise |
|------------|-----------|
| **Hugo** | Copywriting stratégique |
| **Théo** *(landing-page)* | Landing pages & pages de capture |
| **Nora** | Email marketing & séquences |
| **Cora** | Sujets d'email & taux d'ouverture |
| **Julien** | Newsletter & communauté email |
| **Ruby** | Croissance liste email |
| **Sally** | Storytelling de vente |
| **Phoenix** | Réécriture & paraphrase |
| **Sage** | Synthèse & résumés |

### 📱 Réseaux Sociaux & Vidéo
| Spécialiste | Expertise |
|------------|-----------|
| **Clara** | Instagram & création de contenu |
| **Léonard** | LinkedIn & personal branding |
| **Leo** | Scripts viraux & hooks vidéo |
| **Vex** | Hooks viraux pour vidéos courtes |
| **Viddi** | Idéation YouTube Shorts |
| **Ava** | Croissance TikTok/Reels/Shorts |
| **Zoé** | Stratégie multi-réseaux |
| **Dina** | Contenu digital multi-plateforme |
| **Mia** | Repurposing de contenu |

### 📣 Marketing & Acquisition
| Spécialiste | Expertise |
|------------|-----------|
| **Paul** | Génération de leads |
| **Axel** | Meta Ads (Facebook & Instagram) |
| **Raphaël** | Google Ads & SEA |
| **Théo** *(seo)* | SEO & référencement naturel |
| **Thomas** | Prospection & cold outreach |
| **Adrien** | Stratégie de lancement produit |
| **Lila** | Affiliation & partenariats affiliés |

### 🏗️ Stratégie & Business
| Spécialiste | Expertise |
|------------|-----------|
| **Florian** | Stratégie d'entreprise & plan 90 jours |
| **Valentin** | Vision & objectifs stratégiques |
| **Étienne** | Analyse de marché |
| **Baptiste** | Développement de produit digital |
| **Nicolas** | Monétisation & diversification |
| **Blake** | E-commerce & optimisation conversion |
| **Echo** | Pitch investisseurs & partenaires |
| **Laura** | KPIs & analyse de performance |

### 🤖 IA & Automatisation
| Spécialiste | Expertise |
|------------|-----------|
| **Hugo** *(IA)* | Spécialiste IA généraliste & orientation |
| **Estelle** | Intégration IA en entreprise |
| **Antoine** | Automatisation & workflows |
| **Mathieu** | Workflows IA avancés & agents |
| **Alexis** | Prompts IA & utilisation avancée de Claude |
| **Gabriel** | Outils IA & productivité tech |

### 📚 Formation & Coaching
| Spécialiste | Expertise |
|------------|-----------|
| **Manon** | Création de formation en ligne |
| **Sarah** | Pédagogie & structure de cours |
| **Pauline** | Coaching & programmes de mentorat |
| **Barbara** | Blog & contenu SEO long format |
| **Milo** | Écriture de livre |
| **Orion** | Présentations & slides |

### 🤝 Relation Client & Équipe
| Spécialiste | Expertise |
|------------|-----------|
| **Jade** | Relation client & fidélisation |
| **Ana** | Service client & scripts |
| **Marie** | Onboarding client |
| **Romain** | Délégation & management |
| **Sophie** | Partenariats & collaborations |
| **Amandine** | Avatar client & persona |

### ⚡ Productivité & Performance
| Spécialiste | Expertise |
|------------|-----------|
| **Élise** | Gestion du temps & priorités |
| **Inès** | Routines & habitudes de performance |
| **Camille** | Gestion de projets |
| **Nathan** | Assistant virtuel & organisation |
| **Margaux** | Équilibre vie pro/perso |
| **Océan** | Mindset entrepreneur |

### 🔧 Outils & Techniques
| Spécialiste | Expertise |
|------------|-----------|
| **Emma** | Stratégie de contenu & planning |
| **Phoebe** | Logo & identité visuelle |
| **Emmi** | Excel & Google Sheets |
| **Iris** | Innovation & créativité |
| **Sofia** | Branding & identité de marque |

---

## Comment utiliser un spécialiste ?

Dis simplement à Claude ce que tu veux faire. Par exemple :

> "J'ai besoin d'un script de vente pour mon programme IA à 997€"
> "Génère-moi 10 idées de YouTube Shorts sur l'automatisation"
> "Audite mon tunnel de vente et dis-moi où je perds des clients"
> "Écris-moi un hook viral pour mon Reel sur ChatGPT"

Claude active automatiquement le bon spécialiste.

---

## Infos

- **Version** : 1.0.0
- **Langue** : Français
- **Créateur** : Maîtrise IA — Arnaud Aka
- **Instagram** : [@arnaud_aka](https://instagram.com/arnaud_aka)
- **Site** : [50-specialistes-ia.netlify.app](https://50-specialistes-ia.netlify.app)
